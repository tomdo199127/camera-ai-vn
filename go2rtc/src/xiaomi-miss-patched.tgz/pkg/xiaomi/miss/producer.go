package miss

import (
	"fmt"
	"net/url"
	"os"
	"time"

	"github.com/AlexxIT/go2rtc/pkg/core"
	"github.com/AlexxIT/go2rtc/pkg/h264"
	"github.com/AlexxIT/go2rtc/pkg/h264/annexb"
	"github.com/AlexxIT/go2rtc/pkg/h265"
	"github.com/pion/rtp"
)

type Producer struct {
	core.Connection
	client  *Client
	pending []*Packet // read while probing, sent first
}

func Dial(rawURL string) (core.Producer, error) {
	t0 := time.Now()
	client, err := NewClient(rawURL)
	if err != nil {
		debugf("dial: %v (%v)", err, time.Since(t0))
		return nil, err
	}
	debugf("dial: connected in %v", time.Since(t0))

	u, _ := url.Parse(rawURL)
	query := u.Query()

	if start := query.Get("playback"); start != "" {
		// recordings from the SD card instead of live video
		err = client.StartPlayback(start, query.Get("speed"), query.Get("channel"))
	} else {
		err = client.StartMedia(query.Get("channel"), query.Get("subtype"), query.Get("audio"))
	}
	debugf("start: %v after dial (err %v)", time.Since(t0), err)
	if err != nil {
		_ = client.Close()
		return nil, err
	}

	tp := time.Now()
	medias, pending, err := probe(client, query.Get("audio") != "0")
	debugf("probe: %v (err %v)", time.Since(tp), err)
	ua := client.Version()
	if client.PlaybackStart != 0 {
		ua += fmt.Sprintf(" playback=%d", client.PlaybackStart) // read back via /api/streams
		if len(pending) > 0 {
			ua += fmt.Sprintf(" ts0=%d", pending[0].Timestamp) // camera time of the first frame (ms)
		}
	}
	if err != nil {
		_ = client.Close()
		return nil, err
	}

	return &Producer{
		Connection: core.Connection{
			ID:         core.NewID(),
			FormatName: "xiaomi/miss",
			Protocol:   client.Protocol(),
			RemoteAddr: client.RemoteAddr().String(),
			UserAgent:  ua,
			Medias:     medias,
			Transport:  client,
		},
		client:  client,
		pending: pending,
	}, nil
}

// probe reads packets until the codecs are known; pending - the packets from the first
// video key frame on, sent first when the producer starts (else the picture would wait
// for the next key frame, seconds later).
func probe(client *Client, audio bool) (medias []*core.Media, pending []*Packet, err error) {
	_ = client.SetDeadline(time.Now().Add(15 * time.Second))

	var vcodec, acodec *core.Codec

	for {
		pkt, err := client.ReadPacket()
		if err != nil {
			if vcodec != nil {
				err = fmt.Errorf("no audio")
			} else if acodec != nil {
				err = fmt.Errorf("no video")
			}
			return nil, nil, fmt.Errorf("xiaomi: probe: %w", err)
		}

		if debugCommands {
			fmt.Fprintf(os.Stderr, "miss: probe packet codec 0x%x size %d\n", pkt.CodecID, len(pkt.Payload))
		}

		if vcodec != nil {
			pending = append(pending, pkt)
		}

		switch pkt.CodecID {
		case codecH264:
			if vcodec == nil {
				buf := annexb.EncodeToAVCC(pkt.Payload)
				if h264.NALUType(buf) == h264.NALUTypeSPS {
					vcodec = h264.AVCCToCodec(buf)
					pending = append(pending, pkt)
				}
			}
		case codecH265:
			if vcodec == nil {
				buf := annexb.EncodeToAVCC(pkt.Payload)
				if h265.NALUType(buf) == h265.NALUTypeVPS {
					vcodec = h265.AVCCToCodec(buf)
					pending = append(pending, pkt)
				}
			}
		case codecPCMA:
			if acodec == nil {
				acodec = &core.Codec{Name: core.CodecPCMA, ClockRate: 8000}
			}
		case codecOPUS:
			if acodec == nil {
				acodec = &core.Codec{Name: core.CodecOpus, ClockRate: 48000, Channels: 2}
			}
		}

		if vcodec != nil && (acodec != nil || !audio) {
			break
		}
	}

	_ = client.SetDeadline(time.Time{})

	medias = []*core.Media{
		{
			Kind:      core.KindVideo,
			Direction: core.DirectionRecvonly,
			Codecs:    []*core.Codec{vcodec},
		},
	}

	if acodec != nil {
		medias = append(medias, &core.Media{
			Kind:      core.KindAudio,
			Direction: core.DirectionRecvonly,
			Codecs:    []*core.Codec{acodec},
		})

		medias = append(medias, &core.Media{
			Kind:      core.KindAudio,
			Direction: core.DirectionSendonly,
			Codecs:    []*core.Codec{acodec.Clone()},
		})
	}

	return medias, pending, nil
}

const pendingDelay = 800 * time.Millisecond

const timestamp40ms = 48000 * 0.040

// pcmaClockRate: Xiaomi cameras send 16 kHz PCMA declared as 8 kHz, audioTS counts real samples.
const pcmaClockRate = 16000

// audioClock is the first audio timestamp of a live session. go2rtc reconnects a lost camera
// while RTSP consumers stay attached: starting from 0 sends audio time backwards for them
// (ffmpeg then writes broken or shifted audio), starting from the clock keeps it moving forward
// by the real length of the gap.
func audioClock(rate int64) uint32 {
	return uint32(time.Now().UnixMilli() * rate / 1000)
}

func (p *Producer) Start() error {
	var audioTS uint32
	var audioStarted bool        // live: audio time starts from the clock, see audioClock
	var fileStart, lastTS uint64 // playback: start of the SD card file being played (ms) and the last video time
	if p.client.PlaybackStart != 0 {
		fileStart = uint64(p.client.PlaybackStart) * 1000
	}

	if len(p.pending) > 0 {
		// the producer starts when a consumer is added (RTSP DESCRIBE), but an RTSP consumer
		// drops packets until its SETUP: give it a moment, so the key frame read while
		// probing reaches it (else the picture waits for the next key frame, ~3 s)
		time.Sleep(pendingDelay)
	}

	for {
		var pkt *Packet
		if len(p.pending) > 0 { // read while probing
			pkt, p.pending = p.pending[0], p.pending[1:]
		} else {
			_ = p.client.SetDeadline(time.Now().Add(10 * time.Second))
			var err error
			if pkt, err = p.client.ReadPacket(); err != nil {
				return err
			}
		}

		p.Recv += len(pkt.Payload)

		// TODO: rewrite this
		var name string
		var pkt2 *core.Packet

		switch pkt.CodecID {
		case codecH264, codecH265:
			ts := pkt.Timestamp
			if fileStart != 0 {
				// SD card playback goes on with the next files, but the camera time starts again from 0
				// in every file: count it from the first file, using the file starts of the SD card list
				// (a gap on the card stays a gap)
				ts += fileStart - uint64(p.client.PlaybackStart)*1000
				if lastTS != 0 && ts+1000 < lastTS {
					next := uint64(p.client.NextRecording(int64(fileStart/1000))) * 1000
					if next == 0 || next < fileStart {
						next = fileStart + (lastTS + 50 - ts) // unknown: the files follow one another
					}
					if debugCommands {
						fmt.Fprintf(os.Stderr, "miss: playback next file %d -> %d (camera ts %d)\n", fileStart/1000, next/1000, pkt.Timestamp)
					}
					fileStart = next
					ts = pkt.Timestamp + fileStart - uint64(p.client.PlaybackStart)*1000
				}
				lastTS = ts
			}
			pkt2 = &core.Packet{
				Header: rtp.Header{
					SequenceNumber: uint16(pkt.Sequence),
					Timestamp:      TimeToRTP(ts, 90000),
				},
				Payload: annexb.EncodeToAVCC(pkt.Payload),
			}
			if pkt.CodecID == codecH264 {
				name = core.CodecH264
			} else {
				name = core.CodecH265
			}
		case codecPCMA:
			name = core.CodecPCMA
			if !audioStarted {
				audioStarted = true
				if fileStart == 0 {
					audioTS = audioClock(pcmaClockRate)
				}
			}
			pkt2 = &core.Packet{
				Header: rtp.Header{
					Version:        2,
					Marker:         true,
					SequenceNumber: uint16(pkt.Sequence),
					Timestamp:      audioTS,
				},
				Payload: pkt.Payload,
			}
			audioTS += uint32(len(pkt.Payload))
		case codecOPUS:
			name = core.CodecOpus
			if !audioStarted {
				audioStarted = true
				if fileStart == 0 {
					audioTS = audioClock(48000)
				}
			}
			pkt2 = &core.Packet{
				Header: rtp.Header{
					Version:        2,
					Marker:         true,
					SequenceNumber: uint16(pkt.Sequence),
					Timestamp:      audioTS,
				},
				Payload: pkt.Payload,
			}
			// known cameras sends packets with 40ms long
			audioTS += timestamp40ms
		}

		for _, recv := range p.Receivers {
			if recv.Codec.Name == name {
				recv.WriteRTP(pkt2)
				break
			}
		}
	}
}

func (p *Producer) Stop() error {
	_ = p.client.StopMedia()
	return p.Connection.Stop()
}

// Motor sends a pan/tilt step over this producer's session. The camera allows
// one session, so motor commands must share it rather than dial a second one.
func (p *Producer) Motor(operation int) error {
	return p.client.Motor(operation)
}

// Request sends a MISS command and waits for the response with code resp.
func (p *Producer) Request(cmd uint32, params string, resp uint32, timeout time.Duration) ([]byte, error) {
	return p.client.Request(cmd, params, resp, timeout)
}

// Command sends a MISS command over this producer's session.
func (p *Producer) Command(cmd uint32, params string) error {
	return p.client.Command(cmd, params)
}

// SDFiles returns the files on the SD card (over this session).
func (p *Producer) SDFiles(timeout time.Duration) ([]SDFile, error) {
	return p.client.SDFiles(timeout)
}

// SDEvents returns the event types of the SD card recordings of a day (over this session).
func (p *Producer) SDEvents(day string, timeout time.Duration) ([]SDEvent, error) {
	return p.client.SDEvents(day, timeout)
}

// TimeToRTP convert time in milliseconds to RTP time
func TimeToRTP(timeMS, clockRate uint64) uint32 {
	return uint32(timeMS * clockRate / 1000)
}
